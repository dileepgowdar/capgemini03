import { useEffect, useState } from 'react';

const API_URL = 'http://localhost:8076';

export default function App() {
  const [admins, setAdmins] = useState([]);
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [selectedId, setSelectedId] = useState(null);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const getAdmins = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/getadmin`);
      if (!response.ok) throw new Error('Unable to fetch admins');
      const data = await response.json();
      setAdmins(data);
    } catch (error) {
      console.error(error);
      setMessage('Cannot connect to backend. Start Spring Boot on port 8076.');
    } finally {
      setLoading(false);
    }
  };

  const saveAdmin = async () => {
    if (!name.trim() || !password.trim()) {
      setMessage('Please enter name and password.');
      return;
    }
    try {
      const response = await fetch(`${API_URL}/saveadmin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), password })
      });
      if (!response.ok) throw new Error('Save failed');
      setMessage('Admin saved successfully.');
      clearForm();
      await getAdmins();
    } catch (error) {
      console.error(error);
      setMessage('Failed to save admin.');
    }
  };

  const selectAdmin = (admin) => {
    setSelectedId(admin.id);
    setName(admin.name || '');
    setPassword(admin.password || '');
    setMessage(`Admin ${admin.id} selected for update/delete.`);
  };

  const updateAdmin = async () => {
    if (selectedId === null) {
      setMessage('Select an admin from the table first.');
      return;
    }
    if (!name.trim() || !password.trim()) {
      setMessage('Please enter name and password.');
      return;
    }
    try {
      const response = await fetch(`${API_URL}/updateadmin/${selectedId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), password })
      });
      if (!response.ok) throw new Error('Update failed');
      setMessage('Admin updated successfully.');
      clearForm();
      await getAdmins();
    } catch (error) {
      console.error(error);
      setMessage('Failed to update admin.');
    }
  };

  const deleteAdmin = async (id = selectedId) => {
    if (id === null || id === undefined) {
      setMessage('Select an admin first.');
      return;
    }
    if (!window.confirm('Are you sure you want to delete this admin?')) return;
    try {
      const response = await fetch(`${API_URL}/deleteadmin/${id}`, {
        method: 'DELETE'
      });
      if (!response.ok) throw new Error('Delete failed');
      setMessage('Admin deleted successfully.');
      clearForm();
      await getAdmins();
    } catch (error) {
      console.error(error);
      setMessage('Failed to delete admin.');
    }
  };

  const clearForm = () => {
    setName('');
    setPassword('');
    setSelectedId(null);
  };

  useEffect(() => {
    getAdmins();
  }, []);

  return (
    <div className="page">
      <header className="header">
        <div>
          <h1>Placement Admin Management</h1>
          <p>Manage administrator accounts</p>
        </div>
      </header>

      <main className="content">
        <section className="card form-card">
          <h2>{selectedId === null ? 'Add Admin' : `Edit Admin #${selectedId}`}</h2>

          <label htmlFor="name">Name</label>
          <input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter admin name"
          />

          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter password"
          />

          <div className="actions">
            <button className="save" onClick={saveAdmin}>Save Admin</button>
            <button className="update" onClick={updateAdmin}>Update Admin</button>
            <button className="delete" onClick={() => deleteAdmin()}>Delete Admin</button>
          </div>

          {message && <p className="message">{message}</p>}
        </section>

        <section className="card table-card">
          <div className="table-title">
            <h2>Admin List</h2>
            <span>{loading ? 'Loading...' : `${admins.length} admin(s)`}</span>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Password</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {admins.length === 0 ? (
                  <tr>
                    <td colSpan="4" className="empty">No admins found.</td>
                  </tr>
                ) : (
                  admins.map((admin) => (
                    <tr key={admin.id} className={selectedId === admin.id ? 'selected' : ''}>
                      <td>{admin.id}</td>
                      <td>{admin.name}</td>
                      <td>••••••••</td>
                      <td className="row-actions">
                        <button className="edit" onClick={() => selectAdmin(admin)}>Edit</button>
                        <button className="delete small" onClick={() => deleteAdmin(admin.id)}>Delete</button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
