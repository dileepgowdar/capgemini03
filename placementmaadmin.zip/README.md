# Placement Admin Management - Full Stack

This project contains the Spring Boot backend from the original ZIP plus a React + Vite frontend.

## Project structure

- `backend/` - Spring Boot REST API
- `frontend/` - React + Vite UI

## Backend

The backend runs on port `8076` and connects to PostgreSQL.

Current `application.properties` settings:

- Database: `Dileep11`
- PostgreSQL port: `5432`
- Username: `postgres`
- Password: `1234`
- Server port: `8076`

Make sure PostgreSQL is running and the `Dileep11` database exists.

### Start backend

From the `backend` folder:

Windows PowerShell:

```powershell
.\mvnw.cmd spring-boot:run
```

Or run `PlacementmanagementdemoprogramApplication.java` from Spring Tool Suite/Eclipse.

Test:

`http://localhost:8076/getadmin`

## Frontend

From the `frontend` folder:

```powershell
npm install
npm run dev
```

Open:

`http://localhost:5173`

The frontend calls the backend at `http://localhost:8076`.

## Available API endpoints

- `POST /saveadmin` - create admin
- `GET /getadmin` - list all admins
- `GET /getadmin/{id}` - get one admin
- `PUT /updateadmin/{id}` - update admin
- `DELETE /deleteadmin/{id}` - delete admin

## Frontend features

- Save Admin
- Update Admin
- Delete Admin
- Edit an admin from the table
- View all admins
- Automatic backend loading on page open
- CORS already enabled in the backend controller

## Important

The current backend stores the password as plain text in PostgreSQL. This is suitable only for a simple academic/demo project. For a real application, passwords should be hashed and authentication should be implemented.
