package com.util.Encapsulation;
class product{
	private double price;
		
	
				


	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		if(price>0) {
			
		
		this.price = price;
	}
	else {
		System.out.println("invalid price");
	}

}
}

public class Product {
public static void main(String[] args) {
	product p=new product();
	p.setPrice(25000);
	System.out.println("product price"+p.getPrice());
	p.setPrice(-600);
}
}

